// Funny story variables
const heroName = "Detective Waffles";
const sidekick = "Slappy the Squirrel";
let action = "slipped on a banana peel";
let object = "giant rubber chicken";
let villain = "Dr. Pickle";
let place = "a donut shop";
let twist = "they accidentally formed a boy band and went on tour";

// Construct the story
let story = `
One day, ${heroName} and their trusty sidekick ${sidekick} were chasing ${villain} through ${place}.
Suddenly, ${heroName} ${action} while holding a ${object}.
Everyone gasped, but then ${twist}.
It was the weirdest Tuesday ever.
`;

console.log("--- Funny Story ---");
console.log(story);

// Change values for a new version
action = "accidentally launched a taco into space";
object = "flaming ukulele";
villain = "The Toastmaster";
place = "a cheese museum";
twist = "but then they baked a croissant so perfect it caused world peace";

story = `
One day, ${heroName} and their trusty sidekick ${sidekick} were chasing ${villain} through ${place}.
Suddenly, ${heroName} ${action} while holding a ${object}.
Everyone gasped, but then ${twist}.
It was the weirdest Tuesday ever.
`;

console.log("--- Different Versoin of the Story ---");
console.log(story);
