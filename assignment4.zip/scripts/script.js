console.log("Script");

// str
let firstName = 'Marina';
let lastName = 'Longnickel'

// num
let age = 23;
let mySize = 1;

// bool
let isStudent = false;

console.log(firstName);
console.log(age, mySize);

// concatenation
console.log("My name is " + firstName + " " + lastName);

// operations

let n1 = 10;
let n2 = 2;

let addition = n1 + n2;
let subtraction = n1 - n2;
let multiplication = n1 * n2;
let division = n1 / n2;

console.log("Addition is: " + addition);
console.log("Subtraction is: " + subtraction);
console.log("Multiplication is: " + multiplication);
console.log("Division is: " + division);

let r = 3;
const pi = 3.14;
let a = pi * r**2

console.log("The area of a circle with a radius " + r + " is " + a)